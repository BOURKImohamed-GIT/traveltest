<?php
/**
 * travel/v1 REST routes consumed by the React frontend.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', 'tac_register_routes' );

function tac_register_routes() {
	$ns = 'travel/v1';

	register_rest_route(
		$ns,
		'/tours',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'tac_rest_list_tours',
			'permission_callback' => '__return_true',
			'args'                => array(
				'search'      => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
				'category'    => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_title' ),
				'min_price'   => array( 'type' => 'number' ),
				'max_price'   => array( 'type' => 'number' ),
				'min_rating'  => array( 'type' => 'number' ),
				// Filters from the schema: comma-separated values, e.g. ?languages=English,French&tour_style=private.
				'duration_type'     => array( 'type' => 'string' ),
				'city'              => array( 'type' => 'string' ),
				'tour_style'        => array( 'type' => 'string' ),
				'activity_level'    => array( 'type' => 'string' ),
				'booking_type'      => array( 'type' => 'string' ),
				'experience_style'  => array( 'type' => 'string' ),
				'languages'         => array( 'type' => 'string' ),
				'traveler_types'    => array( 'type' => 'string' ),
				'time_of_day'       => array( 'type' => 'string' ),
				'accessibility'     => array( 'type' => 'string' ),
				'included_services' => array( 'type' => 'string' ),
				'free_cancel'       => array( 'type' => 'boolean' ),
				'date'              => array( 'type' => 'string', 'pattern' => '^\\d{4}-\\d{2}-\\d{2}$' ),
				'sort'        => array(
					'type'    => 'string',
					'enum'    => array( 'recommended', 'rating', 'price_asc', 'price_desc' ),
					'default' => 'recommended',
				),
				'page'        => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
				'per_page'    => array( 'type' => 'integer', 'default' => 12, 'minimum' => 1, 'maximum' => 50 ),
			),
		)
	);

	register_rest_route(
		$ns,
		'/tours/(?P<slug>[a-z0-9-]+)',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'tac_rest_get_tour',
			'permission_callback' => '__return_true',
		)
	);

	register_rest_route(
		$ns,
		'/tours/(?P<id>\d+)/reviews',
		array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => 'tac_rest_list_reviews',
				'permission_callback' => '__return_true',
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'tac_rest_create_review',
				'permission_callback' => '__return_true',
				'args'                => array(
					'author'     => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
					'email'      => array( 'type' => 'string', 'required' => true, 'format' => 'email' ),
					'rating'     => array( 'type' => 'integer', 'required' => true, 'minimum' => 1, 'maximum' => 5 ),
					'title'      => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
					'content'    => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_textarea_field' ),
					'tripType'   => array( 'type' => 'string', 'enum' => array( '', 'business', 'couples', 'family', 'friends', 'solo' ), 'default' => '' ),
					'travelDate' => array( 'type' => 'string', 'pattern' => '^(\d{4}-\d{2})?$', 'default' => '' ),
					'website'    => array( 'type' => 'string', 'default' => '' ), // Honeypot.
				),
			),
		)
	);

	register_rest_route(
		$ns,
		'/tour-categories',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'tac_rest_list_categories',
			'permission_callback' => '__return_true',
		)
	);

	register_rest_route(
		$ns,
		'/pages/(?P<slug>[a-z0-9-]+)',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'tac_rest_get_page',
			'permission_callback' => '__return_true',
		)
	);

	register_rest_route(
		$ns,
		'/contact',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => 'tac_rest_contact',
			'permission_callback' => '__return_true',
			'args'                => array(
				'name'    => array( 'type' => 'string', 'required' => true, 'minLength' => 2, 'maxLength' => 80, 'sanitize_callback' => 'sanitize_text_field' ),
				'email'   => array( 'type' => 'string', 'required' => true, 'format' => 'email' ),
				'phone'   => array( 'type' => 'string', 'default' => '', 'maxLength' => 30, 'sanitize_callback' => 'sanitize_text_field' ),
				'subject' => array( 'type' => 'string', 'default' => '', 'maxLength' => 120, 'sanitize_callback' => 'sanitize_text_field' ),
				'message' => array( 'type' => 'string', 'required' => true, 'minLength' => 10, 'maxLength' => 5000, 'sanitize_callback' => 'sanitize_textarea_field' ),
				'website' => array( 'type' => 'string', 'default' => '' ), // Honeypot.
			),
		)
	);

	register_rest_route(
		$ns,
		'/inquiries',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => 'tac_rest_create_inquiry',
			'permission_callback' => '__return_true',
			'args'                => array(
				'tourId'  => array( 'type' => 'integer', 'required' => true ),
				'name'    => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
				'email'   => array( 'type' => 'string', 'required' => true, 'format' => 'email' ),
				'phone'   => array( 'type' => 'string', 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
				'date'    => array( 'type' => 'string', 'required' => true, 'validate_callback' => 'tac_validate_future_date' ),
				'guests'  => array( 'type' => 'integer', 'required' => true, 'minimum' => 1, 'maximum' => 50 ),
				'message' => array( 'type' => 'string', 'default' => '', 'sanitize_callback' => 'sanitize_textarea_field' ),
				'details' => array( 'type' => 'object', 'default' => array() ), // Time, package, pickup… by listing type.
				'website' => array( 'type' => 'string', 'default' => '' ), // Honeypot.
			),
		)
	);
}

/**
 * Accept a YYYY-MM-DD calendar date that is today or later (site timezone).
 */
function tac_validate_future_date( $value ) {
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $value, wp_timezone() );
	if ( ! $date || $date->format( 'Y-m-d' ) !== $value ) {
		return new WP_Error( 'rest_invalid_param', __( 'Date must be in YYYY-MM-DD format.', 'travel-agency-core' ) );
	}
	if ( $date < new DateTimeImmutable( 'today', wp_timezone() ) ) {
		return new WP_Error( 'rest_invalid_param', __( 'Date cannot be in the past.', 'travel-agency-core' ) );
	}
	return true;
}

/* ---------- Formatting ---------- */

function tac_image_url( $post_id, $size = 'large' ) {
	$url = get_the_post_thumbnail_url( $post_id, $size );
	if ( ! $url ) {
		$url = esc_url_raw( (string) get_post_meta( $post_id, 'image_url', true ) );
	}
	return $url ? $url : null;
}

function tac_text( $value ) {
	return html_entity_decode( wp_strip_all_tags( (string) $value ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
}

function tac_lines( $value ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $value ) ) ) );
}

function tac_format_tour( WP_Post $post, $full = false ) {
	// The listing's own category (one of the 17); older listings fall back to their first browse category.
	$listing_cat = tac_listing_category_of( $post->ID );
	$category    = $listing_cat ? get_term_by( 'slug', $listing_cat, 'tour_category' ) : null;
	if ( ! $category ) {
		$terms    = get_the_terms( $post, 'tour_category' );
		$category = $terms && ! is_wp_error( $terms ) ? $terms[0] : null;
	}
	$cat_def = $listing_cat ? tac_listing_category( $listing_cat ) : null;
	$subtype = (string) get_post_meta( $post->ID, 'listing_subtype', true );
	$sub_term = $subtype ? get_term_by( 'slug', $subtype, 'tour_category' ) : null;

	$data = array(
		'id'           => $post->ID,
		'slug'         => $post->post_name,
		'title'        => tac_text( get_the_title( $post ) ),
		'excerpt'      => tac_text( get_the_excerpt( $post ) ),
		'image'        => tac_image_url( $post->ID ),
		'price'        => (float) get_post_meta( $post->ID, 'price', true ),
		// False when the agency hides prices (everywhere, or for this tour); the price is then not sent.
		'showPrice'    => tac_settings()['show_prices'] && ! get_post_meta( $post->ID, 'hide_price', true ),
		'currency'     => get_post_meta( $post->ID, 'currency', true ) ?: 'EUR',
		'priceUnit'    => get_post_meta( $post->ID, 'price_unit', true ) ?: 'per_adult',
		'duration'     => (string) get_post_meta( $post->ID, 'duration', true ),
		'location'     => (string) get_post_meta( $post->ID, 'location', true ),
		'rating'       => (float) get_post_meta( $post->ID, 'rating', true ),
		'reviewCount'  => (int) get_post_meta( $post->ID, 'review_count', true ),
		'freeCancel'   => (bool) get_post_meta( $post->ID, 'free_cancel', true ),
		'groupSize'    => (int) get_post_meta( $post->ID, 'group_size', true ),
		'tourStyle'    => (string) get_post_meta( $post->ID, 'tour_style', true ),
		'startPoint'   => (string) get_post_meta( $post->ID, 'start_point', true ),
		'category'     => $category ? array( 'slug' => $category->slug, 'name' => tac_text( $category->name ) ) : null,
		'subtype'      => $sub_term ? array( 'slug' => $sub_term->slug, 'name' => tac_text( $sub_term->name ) ) : null,
		'listingType'  => $cat_def ? $cat_def['listingType'] : '',
	);

	// Who runs it, on every card: the supplier, or the agency for its own listings.
	$supplier         = tac_public_supplier( (int) $post->post_author );
	$data['supplier'] = $supplier ? array_intersect_key( $supplier, array_flip( array( 'slug', 'name', 'verified', 'logo' ) ) ) : null;

	if ( ! $data['showPrice'] ) {
		$data['price'] = 0;
	}

	if ( $full ) {
		$data['description'] = apply_filters( 'the_content', $post->post_content );
		$data['highlights']   = tac_lines( get_post_meta( $post->ID, 'highlights', true ) );
		$data['amenities']    = tac_lines( get_post_meta( $post->ID, 'amenities', true ) );
		$data['included']     = tac_lines( get_post_meta( $post->ID, 'included', true ) );
		$data['notIncluded']  = tac_lines( get_post_meta( $post->ID, 'not_included', true ) );
		$data['notes']        = tac_lines( get_post_meta( $post->ID, 'notes', true ) );
		$data['endPoint']     = (string) get_post_meta( $post->ID, 'end_point', true );
		$data['meetingPoint'] = (string) get_post_meta( $post->ID, 'meeting_point', true );
		$data['languages']    = array_values( array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, 'languages', true ) ) ) ) );
		$data['itinerary']    = tac_get_itinerary( $post->ID, true ); // Details are HTML from the text editor.
		// Featured image first, then the gallery photos chosen from the Media Library.
		$data['gallery']      = array_values( array_unique( array_filter( array_merge( array( tac_image_url( $post->ID, 'full' ) ), tac_gallery_urls( $post->ID ) ) ) ) );
		// Every field of the listing's category; the app labels and groups them with the schema.
		$data['fields']   = tac_listing_values( $post->ID );
		$data['supplier'] = $supplier;
	}

	return $data;
}

/**
 * Meta queries for the listing filters. Single-choice fields match any of the given values;
 * multiple-choice fields ("English, French") match listings that have any of them.
 */
function tac_listing_filter_query( WP_REST_Request $req ) {
	$values = fn( $key ) => array_values( array_filter( array_map( 'sanitize_text_field', explode( ',', (string) $req[ $key ] ) ), 'strlen' ) );
	$query  = array();
	foreach ( array( 'duration_type', 'city', 'tour_style', 'activity_level', 'booking_type', 'experience_style' ) as $key ) {
		if ( $values( $key ) ) {
			$query[] = array( 'key' => $key, 'value' => $values( $key ), 'compare' => 'IN' );
		}
	}
	foreach ( array( 'languages', 'traveler_types', 'time_of_day', 'accessibility', 'included_services' ) as $key ) {
		if ( $values( $key ) ) {
			$any = array( 'relation' => 'OR' );
			foreach ( $values( $key ) as $v ) {
				$any[] = array( 'key' => $key, 'value' => $v, 'compare' => 'LIKE' );
			}
			$query[] = $any;
		}
	}
	if ( $req['free_cancel'] ) {
		$query[] = array( 'key' => 'free_cancel', 'value' => '1' );
	}
	if ( $req['date'] ) {
		// Runs on that day of the week (listings without operating days are left in).
		$day     = strtolower( gmdate( 'l', strtotime( $req['date'] ) ) );
		$query[] = array(
			'relation' => 'OR',
			array( 'key' => 'operating_days', 'value' => $day, 'compare' => 'LIKE' ),
			array( 'key' => 'operating_days', 'compare' => 'NOT EXISTS' ),
			array( 'key' => 'operating_days', 'value' => '' ),
		);
	}
	return $query;
}

/* ---------- Handlers ---------- */

function tac_rest_list_tours( WP_REST_Request $req ) {
	$args = array(
		'post_type'      => 'tour',
		'post_status'    => 'publish',
		'posts_per_page' => $req['per_page'],
		'paged'          => $req['page'],
		'meta_query'     => array( 'relation' => 'AND' ), // phpcs:ignore WordPress.DB.SlowDBQuery
	) + tac_public_author_args(); // Only businesses' listings (marketplace mode), never suspended accounts'.

	if ( $req['search'] ) {
		$args['s'] = $req['search'];
	}
	if ( $req['category'] ) {
		$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
			array(
				'taxonomy' => 'tour_category',
				'field'    => 'slug',
				'terms'    => $req['category'],
			),
		);
	}
	if ( null !== $req['min_price'] ) {
		$args['meta_query'][] = array( 'key' => 'price', 'value' => (float) $req['min_price'], 'compare' => '>=', 'type' => 'DECIMAL(10,2)' );
	}
	if ( null !== $req['max_price'] ) {
		$args['meta_query'][] = array( 'key' => 'price', 'value' => (float) $req['max_price'], 'compare' => '<=', 'type' => 'DECIMAL(10,2)' );
	}
	if ( null !== $req['min_rating'] ) {
		$args['meta_query'][] = array( 'key' => 'rating', 'value' => (float) $req['min_rating'], 'compare' => '>=', 'type' => 'DECIMAL(3,1)' );
	}
	$args['meta_query'] = array_merge( $args['meta_query'], tac_listing_filter_query( $req ) );

	switch ( $req['sort'] ) {
		case 'rating':
			$args['meta_query']['rating_clause'] = array( 'key' => 'rating', 'type' => 'DECIMAL(3,1)' );
			$args['orderby']                     = array( 'rating_clause' => 'DESC', 'date' => 'DESC' );
			break;
		case 'price_asc':
		case 'price_desc':
			$args['meta_query']['price_clause'] = array( 'key' => 'price', 'type' => 'DECIMAL(10,2)' );
			$args['orderby']                    = array( 'price_clause' => 'price_asc' === $req['sort'] ? 'ASC' : 'DESC' );
			break;
		default:
			// "Recommended": most-reviewed first.
			$args['meta_query']['count_clause'] = array( 'key' => 'review_count', 'type' => 'NUMERIC' );
			$args['orderby']                    = array( 'count_clause' => 'DESC', 'date' => 'DESC' );
	}

	$query = new WP_Query( $args );
	$items = array_map( 'tac_format_tour', $query->posts );

	return tac_paged_response( $items, (int) $query->found_posts, (int) $query->max_num_pages );
}

function tac_paged_response( $items, $total, $pages ) {
	$response = rest_ensure_response( array( 'items' => $items, 'total' => $total, 'totalPages' => $pages ) );
	return $response;
}

function tac_rest_get_tour( WP_REST_Request $req ) {
	// Current address, or an old one (the app then shows the current address).
	$post = tac_listing_by_slug( $req['slug'] );
	if ( ! $post || 'publish' !== $post->post_status || tac_listing_hidden( $post ) ) {
		return new WP_Error( 'not_found', __( 'Tour not found.', 'travel-agency-core' ), array( 'status' => 404 ) );
	}
	return rest_ensure_response( tac_format_tour( $post, true ) );
}

function tac_rest_list_categories() {
	$terms = get_terms( array( 'taxonomy' => 'tour_category', 'hide_empty' => false, 'orderby' => 'term_id' ) );
	if ( is_wp_error( $terms ) ) {
		return $terms;
	}
	$slugs = wp_list_pluck( $terms, 'slug', 'term_id' );
	return rest_ensure_response(
		array_map(
			function ( $t ) use ( $slugs ) {
				return array(
					'slug'   => $t->slug,
					'name'   => tac_text( $t->name ),
					'parent' => $t->parent ? ( $slugs[ $t->parent ] ?? null ) : null,
					'count'  => (int) $t->count,
					'image'  => tac_category_image( $t ),
				);
			},
			$terms
		)
	);
}

/**
 * A category's photo (chosen in Listing categories), or the featured image of one of its tours.
 */
function tac_category_image( WP_Term $term ) {
	$id = (int) get_term_meta( $term->term_id, 'image_id', true );
	if ( $id && wp_get_attachment_image_url( $id, 'large' ) ) {
		return wp_get_attachment_image_url( $id, 'large' );
	}
	$tours = get_posts(
		array(
			'post_type'   => 'tour',
			'numberposts' => 1,
			'fields'      => 'ids',
			'tax_query'   => array( array( 'taxonomy' => 'tour_category', 'terms' => $term->term_id ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	return $tours ? tac_image_url( $tours[0] ) : null;
}

function tac_published_tour_or_error( $id ) {
	$post = get_post( (int) $id );
	if ( ! $post || 'tour' !== $post->post_type || 'publish' !== $post->post_status || tac_listing_hidden( $post ) ) {
		return new WP_Error( 'not_found', __( 'Tour not found.', 'travel-agency-core' ), array( 'status' => 404 ) );
	}
	return $post;
}

function tac_rest_list_reviews( WP_REST_Request $req ) {
	$post = tac_published_tour_or_error( $req['id'] );
	if ( is_wp_error( $post ) ) {
		return $post;
	}
	$comments = get_comments(
		array(
			'post_id' => $post->ID,
			'status'  => 'approve',
			'orderby' => 'comment_date_gmt',
			'order'   => 'DESC',
			'number'  => 50,
		)
	);
	return rest_ensure_response( array_map( 'tac_format_review', $comments ) );
}

/**
 * Simple per-IP throttle for public write endpoints.
 */
function tac_throttled( $bucket, $limit = 5, $window = HOUR_IN_SECONDS ) {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$key = 'tac_' . $bucket . '_' . md5( $ip );
	$hit = (int) get_transient( $key );
	if ( $hit >= $limit ) {
		return true;
	}
	set_transient( $key, $hit + 1, $window );
	return false;
}

function tac_rest_create_review( WP_REST_Request $req ) {
	$post = tac_published_tour_or_error( $req['id'] );
	if ( is_wp_error( $post ) ) {
		return $post;
	}
	if ( '' !== $req['website'] ) {
		// Honeypot filled in: pretend success, store nothing.
		return new WP_REST_Response( array( 'status' => 'pending' ), 202 );
	}
	if ( tac_throttled( 'review' ) ) {
		return new WP_Error( 'too_many_requests', __( 'Too many reviews from this address. Try again later.', 'travel-agency-core' ), array( 'status' => 429 ) );
	}

	// Up to 3 photos (multipart field photos[]).
	$photos = tac_save_uploaded_photos( 'photos', 3, 0, 'review' );
	if ( is_wp_error( $photos ) ) {
		return $photos;
	}

	$comment_id = wp_insert_comment(
		array(
			'comment_post_ID'      => $post->ID,
			'comment_author'       => $req['author'],
			'comment_author_email' => sanitize_email( $req['email'] ),
			'comment_content'      => $req['content'],
			'comment_approved'     => 0,
			'comment_type'         => 'comment',
			'comment_author_IP'    => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
			'comment_meta'         => array(
				'rating'      => (int) $req['rating'],
				'title'       => $req['title'],
				'trip_type'   => $req['tripType'],
				'travel_date' => $req['travelDate'],
				'photos'      => implode( ',', $photos ),
			),
		)
	);

	if ( ! $comment_id ) {
		array_map( fn( $id ) => wp_delete_attachment( $id, true ), $photos );
		return new WP_Error( 'review_failed', __( 'Could not save the review.', 'travel-agency-core' ), array( 'status' => 500 ) );
	}

	return new WP_REST_Response( array( 'status' => 'pending' ), 202 );
}

function tac_rest_create_inquiry( WP_REST_Request $req ) {
	$tour = tac_published_tour_or_error( $req['tourId'] );
	if ( is_wp_error( $tour ) ) {
		return $tour;
	}
	if ( '' !== $req['website'] ) {
		return new WP_REST_Response( array( 'status' => 'received' ), 201 );
	}
	if ( tac_throttled( 'inquiry', 10 ) ) {
		return new WP_Error( 'too_many_requests', __( 'Too many requests from this address. Try again later.', 'travel-agency-core' ), array( 'status' => 429 ) );
	}

	$email      = sanitize_email( $req['email'] );
	$tour_title = $tour->post_title;
	$client     = tac_user_from_request( $req ); // Optional: signed-in travellers see the request in My bookings.
	$supplier   = tac_listing_supplier( $tour );
	$details    = tac_sanitize_booking_details( (array) $req['details'] );
	$lines      = array(
		sprintf( 'Listing: %s', $tour_title ),
		sprintf( 'Name: %s', $req['name'] ),
		sprintf( 'Email: %s', $email ),
		sprintf( 'Phone: %s', $req['phone'] ),
		sprintf( 'Date: %s', $req['date'] ),
		sprintf( 'Guests: %d', $req['guests'] ),
	);
	foreach ( $details as $key => $value ) {
		$lines[] = sprintf( '%s: %s', tac_booking_detail_labels()[ $key ], $value );
	}
	$lines[] = '';
	$lines[] = $req['message'];
	$body    = implode( "\n", $lines );

	$inquiry_id = wp_insert_post(
		array(
			'post_type'    => 'inquiry',
			'post_status'  => 'private',
			'post_title'   => sprintf( '%s — %s (%s)', $req['name'], $tour_title, $req['date'] ),
			'post_content' => $body,
			'meta_input'   => array(
				'tour_id'   => $tour->ID,
				'client_id' => $client ? $client->ID : 0,
				'name'      => $req['name'],
				'email'     => $email,
				'phone'     => $req['phone'],
				'guests'    => (int) $req['guests'],
				'date'      => $req['date'],
				'message'   => $req['message'],
				'details'   => wp_json_encode( $details ),
				'supplier_id' => $supplier ? $supplier->ID : 0,
				'status'    => 'requested',
			),
		),
		true
	);

	if ( is_wp_error( $inquiry_id ) ) {
		return new WP_Error( 'inquiry_failed', __( 'Could not save the inquiry.', 'travel-agency-core' ), array( 'status' => 500 ) );
	}

	$reply_to = array( 'Reply-To: ' . $req['name'] . ' <' . $email . '>' );
	if ( $supplier ) {
		// A supplier's listing: the request goes to the supplier (the agency only on request, Agency details).
		wp_mail(
			tac_supplier_email( $supplier ),
			sprintf( '[%s] New booking request: %s', tac_site_name(), $tour_title ),
			$body . "\n\n" . sprintf( 'Reply by email, or send an offer, confirm or decline it in your dashboard: %s', tac_frontend_url( '/supplier/bookings' ) ),
			$reply_to
		);
	}
	if ( ! $supplier || tac_settings()['copy_supplier_requests'] ) {
		wp_mail(
			get_option( 'admin_email' ),
			sprintf( '[%s] New booking request: %s', tac_site_name(), $tour_title ),
			( $supplier ? sprintf( "Copy — sent to the supplier %s (%s).\n\n", tac_supplier_name( $supplier ), tac_supplier_email( $supplier ) ) : '' )
				. $body . "\n\n" . sprintf( 'Reply by email, or confirm or decline it in wp-admin: %s', admin_url( 'post.php?action=edit&post=' . $inquiry_id ) ),
			$reply_to
		);
	}

	tac_email_booking_update( $inquiry_id ); // "Request received" with all the details, to the traveller.

	return new WP_REST_Response( array( 'status' => 'received', 'id' => $inquiry_id ), 201 );
}

/**
 * A published WordPress page (About Us, FAQs, policies…) for the app to show.
 */
function tac_rest_get_page( WP_REST_Request $req ) {
	$page = get_page_by_path( $req['slug'], OBJECT, 'page' );
	if ( ! $page || 'publish' !== $page->post_status ) {
		return new WP_Error( 'not_found', __( 'Page not found.', 'travel-agency-core' ), array( 'status' => 404 ) );
	}
	return array(
		'slug'     => $page->post_name,
		'title'    => tac_text( get_the_title( $page ) ),
		'content'  => apply_filters( 'the_content', $page->post_content ),
		'modified' => mysql_to_rfc3339( $page->post_modified_gmt ) . 'Z',
	);
}

/**
 * Contact form: stored with the inquiries and emailed to the agency.
 */
function tac_rest_contact( WP_REST_Request $req ) {
	if ( '' !== $req['website'] ) {
		return new WP_REST_Response( array( 'status' => 'received' ), 201 );
	}
	if ( tac_throttled( 'contact', 5 ) ) {
		return new WP_Error( 'too_many_requests', __( 'Too many messages from this address. Try again later.', 'travel-agency-core' ), array( 'status' => 429 ) );
	}
	$email = sanitize_email( $req['email'] );
	$body  = implode(
		"\n",
		array( sprintf( 'Name: %s', $req['name'] ), sprintf( 'Email: %s', $email ), sprintf( 'Phone: %s', $req['phone'] ), '', $req['message'] )
	);
	$id = wp_insert_post(
		array(
			'post_type'    => 'inquiry',
			'post_status'  => 'private',
			'post_title'   => sprintf( 'Message: %s — %s', $req['name'], $req['subject'] ?: __( 'Contact form', 'travel-agency-core' ) ),
			'post_content' => $body,
			'meta_input'   => array(
				'tour_id' => 0,
				'name'    => $req['name'],
				'email'   => $email,
				'phone'   => $req['phone'],
				'message' => $req['message'],
				'status'  => 'message',
			),
		),
		true
	);
	if ( is_wp_error( $id ) ) {
		return new WP_Error( 'contact_failed', __( 'Could not send your message.', 'travel-agency-core' ), array( 'status' => 500 ) );
	}
	wp_mail(
		get_option( 'admin_email' ),
		sprintf( '[%s] %s', tac_site_name(), $req['subject'] ?: 'New message from the contact form' ),
		$body,
		array( 'Reply-To: ' . $req['name'] . ' <' . $email . '>' )
	);
	return new WP_REST_Response( array( 'status' => 'received' ), 201 );
}
