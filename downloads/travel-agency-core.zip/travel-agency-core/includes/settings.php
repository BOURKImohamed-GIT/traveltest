<?php
/**
 * Agency details: contact information and social media links, edited in
 * wp-admin → Agency details and shown in the site footer and on Contact Us.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TAC_SETTINGS_OPTION = 'tac_agency_settings';

/** Social networks shown as icons in the footer. */
function tac_social_networks() {
	return array(
		'facebook'  => 'Facebook',
		'x'         => 'X (Twitter)',
		'instagram' => 'Instagram',
		'pinterest' => 'Pinterest',
		'linkedin'  => 'LinkedIn',
	);
}

function tac_settings() {
	$saved = get_option( TAC_SETTINGS_OPTION, array() );
	return wp_parse_args(
		is_array( $saved ) ? $saved : array(),
		array(
			'email'    => '',
			'phone'    => '',
			'whatsapp' => '',
			'address'  => '',
			'about'    => '',
			'logo'     => '',
			'payments' => '',
			// Prices are shown unless the agency turns them off.
			'show_prices' => true,
			// Supplier listings wait for an admin's approval before going live.
			'review_listings' => true,
			// Marketplace mode: only businesses' listings are public; none in the platform's own name.
			'marketplace_only' => true,
			'google_client_id' => '',
			// Booking requests for suppliers' listings go to the supplier only, unless this is on.
			'copy_supplier_requests' => false,
			'social'   => array(),
		)
	);
}

/**
 * Clean submitted settings. Social rows without a valid URL are dropped.
 */
function tac_sanitize_settings( $raw ) {
	$raw      = is_array( $raw ) ? $raw : array();
	$networks = tac_social_networks();
	$social   = array();
	foreach ( (array) ( $raw['social'] ?? array() ) as $row ) {
		$network = sanitize_key( $row['network'] ?? '' );
		$url     = esc_url_raw( trim( (string) ( $row['url'] ?? '' ) ), array( 'http', 'https' ) );
		if ( ! $url || ! isset( $networks[ $network ] ) ) {
			continue;
		}
		$social[] = array(
			'network' => $network,
			'label'   => $networks[ $network ],
			'url'     => $url,
		);
	}
	return array(
		'email'    => sanitize_email( $raw['email'] ?? '' ),
		'phone'    => sanitize_text_field( $raw['phone'] ?? '' ),
		// wa.me needs the international number as digits only.
		'whatsapp' => preg_replace( '/\D/', '', (string) ( $raw['whatsapp'] ?? '' ) ),
		'address'  => sanitize_textarea_field( $raw['address'] ?? '' ),
		'about'    => sanitize_textarea_field( $raw['about'] ?? '' ),
		'logo'     => esc_url_raw( trim( (string) ( $raw['logo'] ?? '' ) ), array( 'http', 'https' ) ),
		'payments' => sanitize_text_field( $raw['payments'] ?? '' ),
		'show_prices' => ! empty( $raw['show_prices'] ),
		'review_listings' => ! empty( $raw['review_listings'] ),
		'marketplace_only' => ! empty( $raw['marketplace_only'] ),
		'copy_supplier_requests' => ! empty( $raw['copy_supplier_requests'] ),
		'google_client_id' => preg_replace( '/[^A-Za-z0-9._-]/', '', (string) ( $raw['google_client_id'] ?? '' ) ),
		'social'   => $social,
	);
}

/* ---------- wp-admin page ---------- */

add_action( 'admin_init', 'tac_register_settings' );

function tac_register_settings() {
	register_setting(
		'tac_agency',
		TAC_SETTINGS_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'tac_sanitize_settings',
		)
	);
}

add_action( 'admin_menu', 'tac_add_settings_page' );

function tac_add_settings_page() {
	add_menu_page(
		__( 'Agency details', 'travel-agency-core' ),
		__( 'Agency details', 'travel-agency-core' ),
		'manage_options',
		'tac-agency',
		'tac_render_settings_page',
		'dashicons-share',
		26
	);
}

function tac_render_settings_page() {
	$s        = tac_settings();
	$name     = TAC_SETTINGS_OPTION;
	$networks = tac_social_networks();
	// Saved links plus three empty rows to add more.
	// Links to sites no longer offered (TikTok, YouTube, review sites…) are dropped on the next save.
	$kept = array_filter( $s['social'], fn( $row ) => isset( $networks[ $row['network'] ?? '' ] ) );
	$rows = array_merge( $kept, array_fill( 0, 3, array( 'network' => '', 'label' => '', 'url' => '' ) ) );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Agency details', 'travel-agency-core' ); ?></h1>
		<?php settings_errors(); // Top-level pages don't show "Settings saved." on their own. ?>
		<?php if ( function_exists( 'tac_theme_bundled' ) && tac_theme_bundled() ) : ?>
			<div class="card" style="max-width:none">
				<h2 style="margin-top:0"><?php esc_html_e( 'Website theme', 'travel-agency-core' ); ?></h2>
				<p><?php esc_html_e( 'This plugin carries the Experience in Morocco theme and keeps it up to date, so you never need to upload the theme zip.', 'travel-agency-core' ); ?></p>
				<p>
					<?php
					echo esc_html(
						TAC_THEME_SLUG === get_stylesheet()
							? ( tac_theme_up_to_date()
								? sprintf( /* translators: %s: plugin version */ __( 'Status: installed, active and up to date (version of plugin %s).', 'travel-agency-core' ), TAC_VERSION )
								: __( 'Status: active but OUT OF DATE. Click the button below to update it.', 'travel-agency-core' ) )
							: ( tac_theme_installed() ? __( 'Status: installed but not active.', 'travel-agency-core' ) : __( 'Status: not installed.', 'travel-agency-core' ) )
					);
					?>
				</p>
				<?php tac_theme_install_button( tac_theme_installed() ? __( 'Update the theme and clear the cache', 'travel-agency-core' ) : __( 'Install and activate the theme', 'travel-agency-core' ) ); ?>
				<p class="description"><?php esc_html_e( 'Still seeing the old design? Also empty your hosting\'s cache (for example LiteSpeed Cache → Purge All) and reload the page with Ctrl + F5.', 'travel-agency-core' ); ?></p>
			</div>
		<?php endif; ?>
		<p><?php esc_html_e( 'Shown on the Contact Us page and in the website footer. Leave a field empty to hide it.', 'travel-agency-core' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'tac_agency' ); ?>
			<h2><?php esc_html_e( 'Contact', 'travel-agency-core' ); ?></h2>
			<table class="form-table">
				<tr>
					<th><label for="tac-email"><?php esc_html_e( 'Email', 'travel-agency-core' ); ?></label></th>
					<td><input class="regular-text" type="email" id="tac-email" name="<?php echo esc_attr( $name ); ?>[email]" value="<?php echo esc_attr( $s['email'] ); ?>"></td>
				</tr>
				<tr>
					<th><label for="tac-phone"><?php esc_html_e( 'Phone', 'travel-agency-core' ); ?></label></th>
					<td><input class="regular-text" id="tac-phone" name="<?php echo esc_attr( $name ); ?>[phone]" value="<?php echo esc_attr( $s['phone'] ); ?>" placeholder="+212 6 00 00 00 00"></td>
				</tr>
				<tr>
					<th><label for="tac-whatsapp"><?php esc_html_e( 'WhatsApp number', 'travel-agency-core' ); ?></label></th>
					<td>
						<input class="regular-text" id="tac-whatsapp" name="<?php echo esc_attr( $name ); ?>[whatsapp]" value="<?php echo esc_attr( $s['whatsapp'] ); ?>" placeholder="212600000000">
						<p class="description"><?php esc_html_e( 'International format with the country code, e.g. 212600000000.', 'travel-agency-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="tac-address"><?php esc_html_e( 'Address', 'travel-agency-core' ); ?></label></th>
					<td><textarea class="large-text" rows="2" id="tac-address" name="<?php echo esc_attr( $name ); ?>[address]"><?php echo esc_textarea( $s['address'] ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="tac-logo"><?php esc_html_e( 'Logo image', 'travel-agency-core' ); ?></label></th>
					<td>
						<input class="large-text" type="url" id="tac-logo" name="<?php echo esc_attr( $name ); ?>[logo]" value="<?php echo esc_attr( $s['logo'] ); ?>" placeholder="https://">
						<p class="description"><?php esc_html_e( 'Upload your logo in Media → Add New, open it, click "Copy URL to clipboard" and paste it here. Leave empty to show the site name.', 'travel-agency-core' ); ?></p>
						<?php if ( $s['logo'] ) : ?>
							<p><img src="<?php echo esc_url( $s['logo'] ); ?>" alt="" style="max-height:80px;background:#fff;padding:6px;border:1px solid #dcdcde"></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><label for="tac-about"><?php esc_html_e( 'About us (footer)', 'travel-agency-core' ); ?></label></th>
					<td>
						<textarea class="large-text" rows="4" id="tac-about" name="<?php echo esc_attr( $name ); ?>[about]"><?php echo esc_textarea( $s['about'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'A few sentences about your agency, shown in the footer.', 'travel-agency-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="tac-payments"><?php esc_html_e( 'Accepted payment', 'travel-agency-core' ); ?></label></th>
					<td>
						<input class="regular-text" id="tac-payments" name="<?php echo esc_attr( $name ); ?>[payments]" value="<?php echo esc_attr( $s['payments'] ); ?>" placeholder="PayPal, bank transfer, Wise, cash">
						<p class="description"><?php esc_html_e( 'Comma separated. The footer shows them as a sentence, e.g. "We accept PayPal, bank transfer, Wise and cash."', 'travel-agency-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Prices', 'travel-agency-core' ); ?></h2>
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Show prices', 'travel-agency-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[show_prices]" value="1" <?php checked( $s['show_prices'] ); ?>> <?php esc_html_e( 'Show tour prices on the website', 'travel-agency-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Untick to hide every price; tours then show "Price on request". To hide the price of one tour only, use "Hide price" on that tour.', 'travel-agency-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Booking requests', 'travel-agency-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[copy_supplier_requests]" value="1" <?php checked( $s['copy_supplier_requests'] ); ?>> <?php esc_html_e( 'Send me a copy of booking requests for suppliers\' listings', 'travel-agency-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Requests for a business\'s listing are emailed to that business only, and the business answers them. You can follow every request under Marketplace → Booking activity.', 'travel-agency-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Supplier listings', 'travel-agency-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[review_listings]" value="1" <?php checked( $s['review_listings'] ); ?>> <?php esc_html_e( 'Review supplier listings before they go live', 'travel-agency-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Submitted listings wait in Marketplace → Listing requests until you approve them. Untick to let suppliers publish directly.', 'travel-agency-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Marketplace mode', 'travel-agency-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[marketplace_only]" value="1" <?php checked( $s['marketplace_only'] ); ?>> <?php esc_html_e( 'Show only listings that belong to a business', 'travel-agency-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Listings in the platform\'s own name are hidden and can\'t be booked, so every booking request goes to a business. Move them to a business in Marketplace → Listings in our name.', 'travel-agency-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Google sign-in', 'travel-agency-core' ); ?></h2>
			<table class="form-table">
				<tr>
					<th id="tac-google"><label for="tac-google-id"><?php esc_html_e( 'Google Client ID', 'travel-agency-core' ); ?></label></th>
					<td>
						<input id="tac-google-id" class="large-text code" name="<?php echo esc_attr( $name ); ?>[google_client_id]" value="<?php echo esc_attr( $s['google_client_id'] ); ?>" placeholder="1234567890-abc123.apps.googleusercontent.com">
						<p class="description">
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s: site address */
									__( 'Shows "Continue with Google" on the sign-in page. In Google Cloud Console → APIs & Services → Credentials, create an OAuth client ID of type "Web application", add %s under Authorized JavaScript origins, and paste the Client ID here. Leave empty to hide the button.', 'travel-agency-core' ),
									untrailingslashit( home_url() )
								)
							);
							?>
						</p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Social media', 'travel-agency-core' ); ?></h2>
			<p><?php esc_html_e( 'Facebook, X, Instagram, Pinterest and LinkedIn icons appear in the footer. Pick a site and paste the full link to your page. To remove a link, empty its URL. Save to get more empty rows.', 'travel-agency-core' ); ?></p>
			<table class="widefat striped" style="max-width:900px">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Site', 'travel-agency-core' ); ?></th>
						<th><?php esc_html_e( 'Link (https://…)', 'travel-agency-core' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $rows as $i => $row ) : ?>
						<tr>
							<td>
								<select name="<?php echo esc_attr( "{$name}[social][$i][network]" ); ?>" aria-label="<?php esc_attr_e( 'Site', 'travel-agency-core' ); ?>">
									<?php foreach ( $networks as $key => $label ) : ?>
										<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $row['network'] ? $row['network'] : 'facebook', $key ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td><input class="large-text" type="url" name="<?php echo esc_attr( "{$name}[social][$i][url]" ); ?>" value="<?php echo esc_attr( $row['url'] ); ?>" placeholder="https://" aria-label="<?php esc_attr_e( 'Link', 'travel-agency-core' ); ?>"></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php submit_button(); ?>
		</form>

		<hr>
		<h2 id="tac-emails"><?php esc_html_e( 'Booking emails', 'travel-agency-core' ); ?></h2>
		<?php tac_render_email_test(); ?>
	</div>
	<?php
}

/**
 * Where booking requests are emailed, and a button to check that this site can send email.
 */
function tac_render_email_test() {
	$to     = get_option( 'admin_email' );
	$result = null;
	if ( isset( $_POST['tac_test_email'] ) && check_admin_referer( 'tac_test_email' ) ) {
		$error = '';
		$catch = function ( WP_Error $e ) use ( &$error ) {
			$error = $e->get_error_message();
		};
		add_action( 'wp_mail_failed', $catch );
		$sent = wp_mail(
			$to,
			sprintf( '[%s] Test email', tac_site_name() ),
			"This is a test from Agency details.\n\nIf you can read this, booking requests and contact messages from your website will reach this inbox."
		);
		remove_action( 'wp_mail_failed', $catch );
		$result = array( $sent, $error );
	}
	?>
	<p>
		<?php
		printf(
			/* translators: 1: email address, 2: link to Settings → General */
			wp_kses( __( 'Booking requests, cancellations and contact messages are sent to <strong>%1$s</strong>, the Administration Email Address in <a href="%2$s">Settings → General</a>.', 'travel-agency-core' ), array( 'strong' => array(), 'a' => array( 'href' => array() ) ) ),
			esc_html( $to ),
			esc_url( admin_url( 'options-general.php' ) )
		);
		?>
	</p>
	<?php if ( $result ) : ?>
		<?php if ( $result[0] ) : ?>
			<div class="notice notice-success inline"><p><?php echo esc_html( sprintf( /* translators: %s: email */ __( 'Test email sent to %s. Check the inbox (and the spam folder). If it does not arrive within a few minutes, your hosting is not delivering WordPress emails: install an SMTP plugin such as "WP Mail SMTP" and connect your email account.', 'travel-agency-core' ), $to ) ); ?></p></div>
		<?php else : ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( __( 'WordPress could not send the email.', 'travel-agency-core' ) . ( $result[1] ? ' ' . $result[1] : '' ) . ' ' . __( 'Install an SMTP plugin such as "WP Mail SMTP" and connect your email account, then try again.', 'travel-agency-core' ) ); ?></p></div>
		<?php endif; ?>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=tac-agency#tac-emails' ) ); ?>">
		<?php wp_nonce_field( 'tac_test_email' ); ?>
		<?php submit_button( __( 'Send test email', 'travel-agency-core' ), 'secondary', 'tac_test_email', false ); ?>
	</form>
	<?php
}

/* ---------- REST ---------- */

add_action( 'rest_api_init', 'tac_register_settings_route' );

function tac_register_settings_route() {
	register_rest_route(
		'travel/v1',
		'/settings',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => function () {
				$s = tac_settings();
				return array(
					'contact'  => array(
						'email'    => $s['email'],
						'phone'    => $s['phone'],
						'whatsapp' => $s['whatsapp'],
						'address'  => $s['address'],
					),
					'about'    => $s['about'],
					'logo'     => $s['logo'],
					'showPrices' => (bool) $s['show_prices'],
					'payments' => array_values( array_filter( array_map( 'trim', explode( ',', $s['payments'] ) ) ) ),
					'social'   => array_values( array_filter( $s['social'], fn( $row ) => isset( tac_social_networks()[ $row['network'] ?? '' ] ) ) ),
				);
			},
			'permission_callback' => '__return_true',
		)
	);
}

// Until a Google Client ID is saved, the sign-in page has no "Continue with Google": say so on the dashboard and here.
add_action(
	'admin_notices',
	function () {
		$screen = get_current_screen();
		if ( tac_google_client_id() || ! current_user_can( 'manage_options' ) || ! $screen || ! in_array( $screen->id, array( 'dashboard', 'toplevel_page_tac-agency' ), true ) ) {
			return;
		}
		printf(
			'<div class="notice notice-info"><p>%s <a href="%s">%s</a></p></div>',
			esc_html__( 'Sign in with Google is off: the "Continue with Google" button appears on the sign-in page once you add your Google Client ID.', 'travel-agency-core' ),
			esc_url( admin_url( 'admin.php?page=tac-agency#tac-google' ) ),
			esc_html__( 'Add it in Agency details → Google sign-in', 'travel-agency-core' )
		);
	}
);
